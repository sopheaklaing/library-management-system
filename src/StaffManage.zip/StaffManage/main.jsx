import React from 'react'
import App from './App'
export default function main() {
  return (
    <div>
        <App/>
    </div>
  )
}
